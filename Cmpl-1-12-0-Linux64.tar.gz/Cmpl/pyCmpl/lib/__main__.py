from pyCmpl import *
from pyCmpl.pyCmplShell import *

pyCmplShell()