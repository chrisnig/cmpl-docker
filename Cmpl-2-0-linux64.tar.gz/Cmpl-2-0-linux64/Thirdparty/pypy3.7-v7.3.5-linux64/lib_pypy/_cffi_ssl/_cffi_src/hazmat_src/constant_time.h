// This file is dual licensed under the terms of the Apache License, Version
// 2.0, and the BSD License. See the LICENSE file in the root of this
// repository for complete details.

uint8_t Cryptography_constant_time_bytes_eq(uint8_t *, size_t, uint8_t *,
                                            size_t);
